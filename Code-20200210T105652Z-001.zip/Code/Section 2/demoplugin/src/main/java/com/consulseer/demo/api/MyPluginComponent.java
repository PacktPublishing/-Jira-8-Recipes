package com.consulseer.demo.api;

public interface MyPluginComponent
{
    String getName();
}